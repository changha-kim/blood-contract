# GDD_05_CONTENT_BUDGET_AND_RULES

# Content Budget (PoC fixed) v0.1.0

## PoC Fixed

- Enemy 3, MiniBoss 1, Hazard 1(Spike Wall), Rooms 5, Cards 18

## Expansion Rule (PoC 통과 후만)

- Enemy 6, Rooms 12, Cards 36
- “종류”보다 “모듈/재조합” 우선