# GDD_02_CONSTITUTION_IMMUTABLE_RULES

# Constitution (v0.1.0)

## Immutable Pillars

- Intent / Synergy / ShortRun / Mobile

## 금지 리스트(우리가 만들지 않는 게임)

- 30~60분 장기 런 전제 하드코어 로그라이크
- 버튼 6개 이상 요구하는 정교 액션
- 시즌/이벤트/UA 전제 라이브옵스
- 컷신 중심 내러티브 RPG

## Lock Rule

- Status=Locked 변경 시: Experiment 기록 → ADR 작성 → Changelog → 버전 업데이트