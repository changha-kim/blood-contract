# ADR | Make Intent Combat Immutable

ADR ID: ADR-20260214-002-Adopt-IntentCombat-As-Immutable
Build Target: poc-0.1.0 (poc-0%201%200%20307777a0189881048febcef792b7153f.md)
Date: February 14, 2026
Decision: Accepted
Related Systems: SYS | Intent Combat (Telegraph→Commit→Execute) (SYS%20Intent%20Combat%20(Telegraph%E2%86%92Commit%E2%86%92Execute)%20307777a01898814a9d3df5820fce8fe9.md)

# Decision

Intent Combat(Commit Lock)을 불변 조건으로 고정.