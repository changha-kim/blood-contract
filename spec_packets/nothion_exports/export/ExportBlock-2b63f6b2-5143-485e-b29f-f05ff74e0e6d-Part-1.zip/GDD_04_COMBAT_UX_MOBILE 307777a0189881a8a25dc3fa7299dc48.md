# GDD_04_COMBAT_UX_MOBILE

# Combat UX (Mobile-first) v0.1.0

## Controls

- Left stick: Move
- Buttons: Attack(오토에임), Dash(넉백/유도 핵심), Skill1

## Auto-aim (PoC)

- 우선순위: Commit 중 위협 > 근접 > 원거리
- 헛스윙 최소화(범위 내 적이 있으면 자동 타겟)

## Telegraph/Commit UI

- 바닥 텔레그래프 + Intent 아이콘
- Commit 순간: 자물쇠/실선/사운드 큐
- (옵션) 마이크로 슬로우 0.1s

## Feedback

- 유도 성공(벽 박힘/아군오인/빗나감) 시: 특수 사운드 + 슬로우 + 짧은 텍스트