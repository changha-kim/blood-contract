# ROOM | Thorn Hall

Complexity(1-5): 1
Difficulty(1-5): 1
Last Verified Build: poc-0.1.0 (poc-0%201%200%20307777a0189881048febcef792b7153f.md)
Patron: Neutral
PoC Scope: Yes
Related Systems: SYS | Intent Combat (Telegraph→Commit→Execute) (SYS%20Intent%20Combat%20(Telegraph%E2%86%92Commit%E2%86%92Execute)%20307777a01898814a9d3df5820fce8fe9.md)
Status: Spec
Tags: KNOCKBACK
Type: Room

# Thorn Hall

## Layout

직사각형 + 한 면 Spike Wall

## Spawns

- Slasher x2

## Goal

Commit 학습 + Spike Wall 첫 성공 유도

## Target Clear Time

60~75s