# GDD_03_CARDS_TAGS_SYNERGY

# Cards / Tags / Synergy (v0.1.0)

## Patrons

- Blood / Iron / Ash (각 6장씩 PoC)

## Tags (PoC 제한)

BLEED, EXECUTE, CURSE, CHAIN, SHIELD, THORN, KNOCKBACK, INTENT

## Synergy Tiers

- 2: Minor (체감 작은 보너스)
- 3: Major (운영이 바뀜)
- 4: Break (판이 뒤집힘, 하이라이트)

## Card UI Rule

- Benefit(이득) / Debt(대가) 분리 표기
- 태그 아이콘 2~3개 이내