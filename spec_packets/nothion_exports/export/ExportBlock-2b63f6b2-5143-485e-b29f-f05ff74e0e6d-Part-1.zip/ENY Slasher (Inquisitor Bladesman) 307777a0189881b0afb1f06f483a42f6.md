# ENY | Slasher (Inquisitor Bladesman)

Complexity(1-5): 2
Difficulty(1-5): 2
Last Verified Build: poc-0.1.0 (poc-0%201%200%20307777a0189881048febcef792b7153f.md)
Patron: Neutral
PoC Scope: Yes
Related Systems: SYS | Intent Combat (Telegraph→Commit→Execute) (SYS%20Intent%20Combat%20(Telegraph%E2%86%92Commit%E2%86%92Execute)%20307777a01898814a9d3df5820fce8fe9.md)
Status: Spec
Tags: INTENT
Type: Enemy

# Slasher

## Role

근접 압박. Commit을 “읽고 유도”하는 첫 학습 대상.

## Intents

1) Lunge Slash

- Telegraph: thin line 3.5m + dmg number
- Commit: LOCK direction
- Execute: 0.18s dash slash
- Recover: 0.45s

2) Wide Sweep

- Telegraph: 140° cone (2.2m)
- Commit: LOCK direction
- Execute: swing
- Recover: 0.65s

## Spike Wall Interaction

- Lunge Slash Commit 후 밀치기로 스파이크 벽에 박히면 큰 리턴.