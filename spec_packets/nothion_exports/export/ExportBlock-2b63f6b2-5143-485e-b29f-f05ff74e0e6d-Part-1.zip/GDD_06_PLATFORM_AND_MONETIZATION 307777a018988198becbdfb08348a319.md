# GDD_06_PLATFORM_AND_MONETIZATION

# Platform & Monetization v0.1.0

## Platform

- Android-first (iOS later)

## Monetization (운영 최소화 추천)

- Free Trial + 1회성 Full Unlock

또는

- Ads minimal + Remove Ads(1회성)