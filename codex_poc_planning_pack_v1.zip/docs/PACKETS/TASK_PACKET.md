# TASK_PACKET (Dev / Codex)

## Task
- Issue: DEV-___
- Target model: gpt-5.3-codex (big) / gpt-5.3-codex-spark (small)
- Files allowed to modify: (explicit)

## Read first
- docs/PACKETS/STATE_PACKET.md
- docs/GDD_SUMMARY.md
- docs/PACKETS/QA_PACKET.md (relevant TCs)

## Requirements
- Must:
- Must NOT:

## Acceptance criteria
- [ ] Runs without crash (desktop)
- [ ] Relevant TC passes or logs show improvement
- [ ] State updated (STATE_PACKET)
