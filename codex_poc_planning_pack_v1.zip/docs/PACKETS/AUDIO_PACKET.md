# AUDIO_PACKET (BGM / SFX)

## PoC audio goals
- Teach Commit moment (LOCK cue)
- Reward “wall-hit success”
- Signal synergy tier up (esp. tier 3)

## Must-have sounds
- Commit lock SFX
- Wall hit / stun SFX
- Dash SFX
- Synergy tier up SFX
- Menu click

## BGM
- 1 loop for combat/run
- 1 loop for menu
- Volume sliders: BGM/SFX
