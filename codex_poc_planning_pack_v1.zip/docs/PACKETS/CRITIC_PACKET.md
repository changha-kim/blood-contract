# CRITIC_PACKET (Red Team)

> 목적: “기획을 넓히기”가 아니라, **PoC 목표 달성을 방해하는 요소를 찾아서 깎기**.
> 규칙: 기능 추가 제안은 원칙적으로 금지. (필요하면 “대체안/스코프 컷” 형태로만)

## What I reviewed
- PLAN_PACKET (link)
- GDD promises: Intent / Synergy / ShortRun / Mobile
- Current risks: Commit confusion, mobile clutter, spike cheese, run length

## Top 5 objections (가장 위험한 허점 5개)
1)
2)
3)
4)
5)

## Scope cuts (이번 주에 잘라야 하는 것 3~5개)
- Cut 1:
- Cut 2:
- Cut 3:

## Testability check (검증 불가능한 문장/목표를 “TC 문장”으로 바꾸기)
- Before:
- After (measurable):

## QA focus suggestions (TC 추천)
- Must:
- Optional:
