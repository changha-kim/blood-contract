# QA_PACKET (Experiments / Test Cases)

## PoC Experiments (from Notion DB_EXPERIMENTS)
- TC01 Commit 이해도 — 무설명 학습
- TC02 텔레그래프 가독성 — 정보 과밀
- TC03 스파이크 치트/무한루프 방지
- TC04 Charger 3초 명장면 재현성
- TC05 시너지 3단계 평균 1회 보장
- TC06 카드 UI(이득/대가) 이해도
- TC07 런타임(6~10분) 수렴
- TC08 공정성(억울함) 분해
- TC09 Android 성능 스모크 테스트
- TC10 빌드 다양성 분포

## This week scope
- Must run:
- Optional:

## Measurement rules (log-based preferred)
- Required log events:
- Output: docs/QA_REPORT.md + logs/metrics.csv

## Pass / Mixed / Fail rubric
- Pass:
- Mixed:
- Fail:
