# PLAN_PACKET (Planner)

## Planning window
- Iteration: Week N (YYYY-MM-DD ~ YYYY-MM-DD)
- Pillars: Intent / Synergy / ShortRun / Mobile
- PoC fixed budget: Enemy 3, MiniBoss 1, Hazard 1(Spike Wall), Rooms 5, Cards 18

## This iteration goals (P0)
1)
2)
3)

## Scope cuts (explicit “NOT doing” list)
- Not doing:

## Deliverables (what “done” looks like)
- Build tag: poc-0.x.y
- Demo scenario:
- TCs to run this week: (예: TC04, TC01)

## Issue bundle (to create / move to Ready)
- [ ] DEV-___ :
- [ ] QA-___ :
- [ ] ART-___ :
- [ ] AUDIO-___ :

## Risks (top 3) + mitigation
1)
2)
3)

## Notes to Dev (Codex)
- Allowed folders: res:// (project), tools/, docs/PACKETS
- Must update: STATE_PACKET “Current build / Known issues / Next actions”
