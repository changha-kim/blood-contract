# PLAN-201 — Week3 목표: 시너지(2/3/4) 구현 + 밸런스(TTK/런타임) + 치트 방지 수치 고정
**Team:** Planning
**Priority:** P0 | **Size:** S
**References:** GDD_10_SYNERGY_TABLE_POC, GDD_09_POC_COMBAT_MATH, GDD_07_RISK_REGISTER

## Acceptance Criteria
- [ ] PLAN_PACKET에 Week3 P0/Scope cut/TC05/TC07/TC03 지정

## Definition of Done
- [ ] Build/run doesn’t crash
- [ ] Relevant logs/metrics updated (if applicable)
- [ ] STATE_PACKET updated (Known issues / Next actions)
