# PLAN-101 — Week2 목표: 5 Rooms + 3 Enemies + Boss + Card Reward + Run End 루프 닫기
**Team:** Planning
**Priority:** P0 | **Size:** S
**References:** GDD_01_CORE_LOOP, GDD_11_UI_FLOW_POC, DB_CONTENT, DB_SYSTEMS

## Acceptance Criteria
- [ ] PLAN_PACKET에 Week2 P0 3개/Scope cut/TC 지정

## Definition of Done
- [ ] Build/run doesn’t crash
- [ ] Relevant logs/metrics updated (if applicable)
- [ ] STATE_PACKET updated (Known issues / Next actions)
