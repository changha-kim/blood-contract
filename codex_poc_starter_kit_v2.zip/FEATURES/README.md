# FEATURES folder

Short, buildable docs only.
- One file per system/content chunk.
- Should fit on 1-2 screens.
- Must include:
  - Goal
  - Player-facing behavior
  - Dev notes
  - Acceptance tests (which TC covers it)
