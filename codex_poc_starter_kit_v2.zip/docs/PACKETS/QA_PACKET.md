# QA_PACKET

## Test scope for this iteration
- Must test:
- Optional:

## Core tests (PoC)
### TC01 - Commit(잠금) 이해도 (무설명 학습)
- Setup:
- Steps:
- Pass if:
- Data to collect:

### TC02 - 텔레그래프 가독성 스트레스 (정보 과밀)
- Pass if:

### TC03 - 스파이크 치트/무한루프 방지
- Pass if:

### TC04 - 3초 트레일러 장면 재현
- Pass if:

## Reporting format
- Verdict: Pass / Mixed / Fail
- Evidence: log file path(s), video/gif (optional), notes
- Next actions (max 3)
