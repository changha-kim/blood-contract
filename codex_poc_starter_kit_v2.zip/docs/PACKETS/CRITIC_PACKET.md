# CRITIC_PACKET (Red Team)

## What I reviewed
- PLAN_PACKET:
- STATE_PACKET:
- Any new ADRs:

## Biggest risks / holes (top 5)
1.
2.
3.
4.
5.

## “Scope creep” alerts
- Things that should be cut or postponed:

## Clarity checks (player)
- What will confuse the player?
- What feedback is missing?

## Suggestions (minimal, not feature creep)
- 1-3 small fixes to increase success odds this week:
1.
2.
3.
