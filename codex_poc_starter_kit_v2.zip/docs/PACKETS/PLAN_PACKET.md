# PLAN_PACKET (Planner)

## Iteration
- Week: W1 / W2 / W3 / W4
- Dates: YYYY-MM-DD ~ YYYY-MM-DD

## This week focus (1 sentence)
- 

## Goals (max 3)
1.
2.
3.

## Non-goals (explicitly NOT doing)
- 

## Deliverable slice (what player can do at end of week)
- 

## Experiments / TCs to run this week (from Notion Experiments DB)
- TC01:
- TC02:
- TC03:
- TC04:

## Required instrumentation (logs)
- Must log:
  - commit events
  - spike wall hits
  - run duration
  - synergy tier triggers
