# AUDIO_PACKET (PoC)

## Audio direction
- Goal: teach Commit & 성공 피드백을 '소리'로 전달

## Must-have SFX (PoC)
- Commit lock cue (distinct, short)
- Telegraph warning (soft)
- Dash
- Spike wall hit (big)
- Stun/execute
- Card pick
- Synergy tier trigger (2/3/4 distinct)

## BGM (PoC)
- 1 loop for combat rooms
- 1 loop for reward/selection (optional)

## Source policy
- Prefer CC0/CC-BY from trusted libraries; log credits
- AI music: only if usage rights are OK for your intended distribution
